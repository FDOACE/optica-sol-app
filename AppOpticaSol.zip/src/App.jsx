
export default function App() {
  return (
    <div className="text-center mt-20">
      <h1 className="text-4xl font-bold text-red-700">Óptica Sol</h1>
      <p className="text-lg text-gray-600 mt-4">Porque tus ojos merecen lo mejor</p>
    </div>
  );
}
